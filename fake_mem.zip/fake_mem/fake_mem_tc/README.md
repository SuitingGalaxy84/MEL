# Fake Memory Module Testbench

This directory contains the testbench for the `fake_mem` module.

## Files

- **generate_mem_data.py**: Python script to generate test data
  - Creates `fake_mem_init.txt` with memory initialization patterns
  - Creates `golden_output.txt` with expected outputs

- **tb_fake_mem.v**: Verilog testbench
  - Tests memory read operations at various addresses
  - Generates `output.txt` with simulation results
  - Creates `tb_fake_mem.vcd` for waveform viewing

- **run_iverilog.ps1**: PowerShell script to run the complete test flow
- **run_iverilog.sh**: Bash script (Linux/Mac compatible)

- **verify.py**: Python script to verify testbench output against golden reference

## Usage

### Windows (PowerShell)
```powershell
.\run_iverilog.ps1
```

### Linux/Mac (Bash)
```bash
chmod +x run_iverilog.sh
./run_iverilog.sh
```

### Manual Steps

1. Generate test data:
   ```bash
   python generate_mem_data.py
   ```

2. Compile and run simulation:
   ```bash
   iverilog -o tb_fake_mem.vvp -g2005-sv ../fake_mem.v tb_fake_mem.v
   vvp tb_fake_mem.vvp
   ```

3. Verify results:
   ```bash
   python verify.py
   ```

## Test Coverage

The testbench covers:
- Sequential address reads (0, 4, 8, 12, 16)
- Mid-range addresses (32, 64, 96, 128)
- Upper range addresses (192, 252)
- Write enable control
- Rapid address changes

## Memory Patterns

The test data includes four distinct patterns:
1. **Sequential** (0x00-0x3F): Incrementing values
2. **Inverse** (0x40-0x7F): Decrementing values from 0xFF
3. **Alternating** (0x80-0xBF): 0xAA and 0x55 pattern
4. **Random** (0xC0-0xFF): Pseudo-random data (seed=42)

## Output Files

- `fake_mem_init.txt`: Memory initialization file (256 bytes)
- `golden_output.txt`: Expected output values
- `output.txt`: Actual testbench output
- `simulation.log`: Complete simulation log
- `tb_fake_mem.vcd`: Waveform data for GTKWave

## Viewing Waveforms

```bash
gtkwave tb_fake_mem.vcd
```
